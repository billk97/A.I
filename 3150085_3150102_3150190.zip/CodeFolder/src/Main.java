
import java.util.Scanner;
import java.util.*;
import  java.io.*;

public  class Main {
    public  static void main(String[] args)
    {
        /**play has all the necessary function to play the game
         * creation of an Object Play**/
        Play p1 = new Play();
        /**calling the play function
         * in this function all the initialisations take place **/
        p1.play();
    }//end main


}//end Main

